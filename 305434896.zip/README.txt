model.py
Git_classifier.pkl

..... description ....

model.py - GitHubClassifier class gets array of string and classify it using classify() method
Git_classifier.pkl - a trained model to load into the class
